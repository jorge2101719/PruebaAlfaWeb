<template>
    <div>
        <AdministraList/>
    </div>
</template>

<script>
import AdministraList from '@/components/AdministraList.vue';

export default {
    name: 'Administracion',
    components: {
        AdministraList
    }
}
</script>