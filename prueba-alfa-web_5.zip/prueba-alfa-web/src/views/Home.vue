<template>
  <div>
    <ListaCursos />
  </div>
</template>

<script>
import ListaCursos from '@/components/ListaCursos.vue'

export default {
  name: 'Home',
  components: {
    ListaCursos
  }
}
</script>
