import Vue from 'vue';
import App from './App.vue';
import router from './router/router';
import store from './store/store';
import vuetify from './plugins/vuetify';

import firebase from 'firebase/app';
// #########################
//import 'firebase/firestore';
// #########################

//import { firebaseConfig } from "@/config/firebaseConfig.js";

const firebaseConfig = {
  apiKey: "AIzaSyAQKBYIidZZ3GVUvYSvxGboqG2p24hKVEY",
  authDomain: "alfaweb-fd076.firebaseapp.com",
  projectId: "alfaweb-fd076",
  storageBucket: "alfaweb-fd076.appspot.com",
  messagingSenderId: "715935293471",
  appId: "1:715935293471:web:9e0f01f5af463e9517752a"
};

firebase.initializeApp(firebaseConfig);

// ##############################################
//const db = firebase.firestore();
//const auth = firebase.auth();
//export { db, auth }
// ##############################################


Vue.config.productionTip = false

new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')