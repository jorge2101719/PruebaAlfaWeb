import Vue from 'vue';
import VueRouter from 'vue-router';
import store from '@/store/store';
//import firebase from 'firebase';

Vue.use(VueRouter)

const routes = [
  {
    path: '/',
    redirect: {name: 'Login'}
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('../views/Login.vue')/* webpackChunkName: "Login" */ 
  },
  {
    path: '/registro',
    name: 'Registro',
    component: () => import('../views/Registro.vue')/* webpackChunkName: "Registro" */ 
  },
  {
    path: '/home',
    name: 'Home',
    meta: {
      requiredAuth: true
    },
    component: () => import('../views/Home.vue')/* webpackChunkName: "Home" */ 
  },
  {
    path: '/administracion',
    name: 'Administracion',
    meta: {
      requiredAuth: true
    },
    component: () => import('../views/Administracion.vue')/* webpackChunkName: "Administracion" */ 
  },
  {
    path: '/editando/:id',
    props: true,
    name: 'Editando',
    meta: {
      requiredAuth: true
    },
    component: () => import('../views/Editando.vue')/* webpackChunkName: "Editando" */ 
  },
  {
    path: '*',
    redirect: {
      name: 'Login'
    }
  }
]

const router = new VueRouter({
  mode: 'history',
  base: process.env.BASE_URL,
  routes
})

router.beforeEach((to,from,next)=>{
  let user = store.getters.enviandoUser;
  //let user = firebase.auth().currentUser;
  let requiredAuth = to.matched.some(res => res.meta.requiredAuth);

  if (!user && requiredAuth) {
    next({name: 'Login'});
  } else if(user && !requiredAuth){
    next('/login');
  } else {
    next();
  }
})



export default router
