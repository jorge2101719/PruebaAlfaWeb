import Vue from 'vue';
import App from './App.vue';
import router from './router/router';
import store from './store/store';
import vuetify from './plugins/vuetify';

import firebase from 'firebase/app';
// #########################
import 'firebase/firestore';
// #########################

import { firebaseConfig } from "@/config/firebaseConfig.js";

firebase.initializeApp(firebaseConfig);

// ##############################################
//const db = firebase.firestore();
//const auth = firebase.auth();
//export { db, auth }
// ##############################################


Vue.config.productionTip = false

new Vue({
  router,
  store,
  vuetify,
  render: h => h(App)
}).$mount('#app')