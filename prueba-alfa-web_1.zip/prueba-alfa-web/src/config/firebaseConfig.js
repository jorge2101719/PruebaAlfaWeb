// Import the functions you need from the SDKs you need
//import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAQKBYIidZZ3GVUvYSvxGboqG2p24hKVEY",
  authDomain: "alfaweb-fd076.firebaseapp.com",
  projectId: "alfaweb-fd076",
  storageBucket: "alfaweb-fd076.appspot.com",
  messagingSenderId: "715935293471",
  appId: "1:715935293471:web:9e0f01f5af463e9517752a"
};

// Initialize Firebase
//const app = initializeApp(firebaseConfig);