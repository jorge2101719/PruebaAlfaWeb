import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'

// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDe9g_PRHqsNXegcnCQAy1ji52PnJBTdD8",
  authDomain: "alfaweb-f72f3.firebaseapp.com",
  projectId: "alfaweb-f72f3",
  storageBucket: "alfaweb-f72f3.appspot.com",
  messagingSenderId: "400363842922",
  appId: "1:400363842922:web:5b1d2ed2e2700b38500913"
};

// Initialize Firebase
initializeApp(firebaseConfig);

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
